package pizza.fooditems;

import pizza.services.Deliverable;

/**
 * Represents an order for a beverage (suds) in the pizza shop app. 
 * Lab Professor: Natalie Gluzman
 * Due Date: March 31, 2024
 * Description: Assignment 02
 * @author	Zarko Milojevic, ID 041113810
 * @version 21.0.1 2023-10-17 LTS
 * @see 	Java(TM) SE Runtime Environment (build 21.0.1+12-LTS-29)
 */

public class SudsOrder implements Deliverable {
	private String name;
	private int number;
	private int sizeInML;

	/**
	 * Constructs a new SudsOrder with the specified details.
	 *
	 * @param name The name of the beverage.
	 * @param number The number of units ordered.
	 * @param sizeInML The size of the beverage in milliliters.
	 */
	public SudsOrder(String name, int number, int sizeInML) {
		this.name = name;
		this.number = number;
		this.sizeInML = sizeInML;
	}

	// Getter methods
	public String getName() {
		return name;
	}

	public int getNumber() {
		return number;
	}

	public int sizeInML() {
		return sizeInML;
	}


	public double deliveryCost() {
		return number*0.75;
	}

	/**
	 * Provides a string representation of the beverage order's details.
	 *
	 * @return The string representation.
	 */
	@Override
	public String toString() {
		return String.format("%s - Quantity: %d - Size: %dml - Delivery Cost: $%.2f",
				name, number, sizeInML, deliveryCost());
	}
}
