package pizza.fooditems;

/**
 * This class is for the toping Pepperoni. 
 * Lab Professor: Natalie Gluzman
 * Due Date: March 31, 2024
 * Description: Assignment 02
 * @author	Zarko Milojevic, ID 041113810
 * @version 21.0.1 2023-10-17 LTS
 * @see 	Java(TM) SE Runtime Environment (build 21.0.1+12-LTS-29)
 */

public class Pepperoni extends FoodItem {
	public Pepperoni(String name) {
		super(name);
	}
}
