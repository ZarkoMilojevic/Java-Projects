package pizza.fooditems;

import pizza.services.Deliverable;
import pizza.fooditems.FoodItem;
import java.util.ArrayList;

/**
 * This class is Pizza and regulates the toppings. 
 * Lab Professor: Natalie Gluzman
 * Due Date: March 31, 2024
 * Description: Assignment 02
 * @author	Zarko Milojevic, ID 041113810
 * @version 21.0.1 2023-10-17 LTS
 * @see 	Java(TM) SE Runtime Environment (build 21.0.1+12-LTS-29)
 */

public class Pizza implements Deliverable {
	public static final boolean THIN_CRUST = true;
	private int sizeInInches;
	private String typeOfSauce;
	private boolean thinCrust; //think over this later, why is it not used
	private FoodItem[] toppings;//aggregate "has-a" relationship
	private int toppingCount; 
	private double basePrice;

	public Pizza(int size, String sauce) {
		this.sizeInInches = size;
		this.typeOfSauce = sauce;
		this.toppings = new FoodItem[7]; //need to initialize otherwise error: array cannot be read 
	}

	public Pizza(int size, double basePrice) {
		this.sizeInInches = size;
		this.basePrice = basePrice;
		this.toppings = new FoodItem[7]; 
	}

	// Getter and setter methods
	public void setBasePrice(double price) {
		this.basePrice = price;
	}

	public void setThinCrust(boolean yes) {
		this.thinCrust = yes;
	}

	public String getTypeOfSauce() {
		return typeOfSauce;
	}

	public FoodItem[] getToppings() {
		return toppings;

	}

	public double getBasePrice() {
		return basePrice;
	}

	public void addTopping(FoodItem item) {
		if (toppingCount < toppings.length) {
			toppings[toppingCount++] = item; // Add item and increment count
		}
	}

	public int sizeInInches() {
		return sizeInInches;
	}

	public double deliveryCost() {
		switch (this.sizeInInches) { //"switch" select one of many code blocks to be executed 
		case 10: return 2.50; //return 2.50 for a 10 inch pizza
		case 12: return 3.50;
		case 14: return 4.75;
		default: return 0; 
		}
	}

	public double price() { //uml: price is base price pluse topping price, this method shoudl calculate topping price
		double toppingsPrice = 0;
		for (int i = 0; i < toppingCount; i++) { //iterate over the toppings array
			toppingsPrice += toppings[i].price(); //accumulate the price of each topping
		}
		return basePrice + toppingsPrice;

	}

	public double totalPrice() {
		return this.price() + this.deliveryCost();
	}

	//    @Override
	//    public String toString() {
	//        // Customized toString implementation
	//        return String.format("Pizza %d-inch with %s sauce and %d toppings. Base price: $%.2f",
	//                sizeInInches, typeOfSauce, toppingCount, basePrice);
	//    }
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		// Add the pizza base information
		sb.append(String.format("Pizza %d-%s%30d $%.2f - Delivery ($%.2f) Total->>$%.2f%n", 
				sizeInInches, 
				typeOfSauce, 
				sizeInInches, 
				getBasePrice(), 
				deliveryCost(), 
				totalPrice()));

		// Iterate over each topping and append its information
		for (int i = 0; i < toppingCount; i++) {
			sb.append(String.format("      - %-30s $%.2f%n", 
					toppings[i].getName(), 
					toppings[i].price()));
		}

		return sb.toString();
	}

}
