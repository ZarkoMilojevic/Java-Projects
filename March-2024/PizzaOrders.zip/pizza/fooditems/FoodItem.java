package pizza.fooditems;

/**
 * This class is for the FoodItem. 
 * Lab Professor: Natalie Gluzman
 * Due Date: March 31, 2024
 * Description: Assignment 02
 * @author	Zarko Milojevic, ID 041113810
 * @version 21.0.1 2023-10-17 LTS
 * @see 	Java(TM) SE Runtime Environment (build 21.0.1+12-LTS-29)
 */

public class FoodItem {
	private String name;
	private String unitsOfMeasure; // e.g., "cup", "slice", "piece"
	private float quantity;
	private double pricePerUnit;

	// Constructor
	public FoodItem(String name) {
		this.name = name;
	}

	// Accessors

	/**
	 * This method returns name.
	 * @return name
	 */
	public String getName() {

		return name;
	}

	/**
	 * This method returns unit of measure.
	 * @return unitsOfMeasurement
	 */

	public String getUnitsOfMeasure() {
		return unitsOfMeasure;
	}

	/**
	 * This method returns quantity.
	 * @return quantity
	 */
	public float getQuantity() {
		return quantity;
	}

	/**
	 * This method returns price per unit.
	 * @return pricePerUnit
	 */
	public double getPricePerUnit() {
		return pricePerUnit;
	}

	// Mutators

	/**
	 * This method defines name.
	 * @param name
	 */

	public void setName(String name) {
		this.name = name;
	}

	/**
	 * This method defines unitsOfMeasure.
	 * @param unitsOfMeasure
	 */
	public void setUnitsOfMeasure(String unitsOfMeasure) {
		this.unitsOfMeasure = unitsOfMeasure;
	}

	/**
	 * This method defines quantity.
	 * @param Quantity
	 */

	public void setQuantity(float quantity) {
		this.quantity = quantity;
	}

	/**
	 * This method defines price per unit.
	 * @param pricePerUnit
	 */

	public void setPricePerUnit(double pricePerUnit) {
		this.pricePerUnit = pricePerUnit;
	}

	/**
	 * This method calculates price as a product.
	 * @return price
	 */
	// Method to calculate the total price of the food item based on quantity and price per unit
	public double price() {
		return quantity * pricePerUnit;
	}

	/**
	 * This method redefines and prints the output.
	 * @return string of different inputs
	 */
	@Override
	public String toString() {
		return String.format("%s: %.2f %s at $%.2f each. Total: $%.2f", name, quantity, unitsOfMeasure, pricePerUnit, price());
	}
}
