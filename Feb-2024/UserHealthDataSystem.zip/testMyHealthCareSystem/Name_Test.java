package testMyHealthCareSystem;

/**
 * This class tests the class Name.
 * Lab Professor: Natalie Gluzman
 * Due Date: Mar 07, 2024
 * @description: Assignment 01
 * @author	Zarko Milojevic, ID 041113810
 * @version 21.0.1 2023-10-17 LTS
 * @see 	Java(TM) SE Runtime Environment (build 21.0.1+12-LTS-29)
 */


/*		@(#)Name_Test.java	Jan. 31, 2024
 *
 */


import static org.junit.jupiter.api.Assertions.*;


import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

import myHealthCareSystem.*;



@DisplayName("Test My HealthCare Application Domain - Name")
@TestMethodOrder(OrderAnnotation.class)
public class Name_Test {

	Name n;

	@BeforeEach
	void setUp() throws Exception {
		/*
		 * Initialize the object prior to test commencing.
		 */
		n = new Name();
	}

	@AfterEach
	void tearDown() throws Exception {
		/*
		 *	Reset the result of previous test.
		 */
		n = null;
	}

	/*		Methods to test
	 * 
			+Name(...)
			+toString():String
			+formattedName():String
			+setFirst(first:String):void
			+setLast(last:String):void
			+setMiddle(middle:String):void
			+setSaluation(salutation:String):void
			+first():String
			+last():String
	 */

	@Nested	@DisplayName("Name() Test")
	@TestMethodOrder(OrderAnnotation.class)
	class NameTest {
		@Test @Order(1) @DisplayName("Name() test with Null arguments")
		final void testNameWithNullArguments() {
			Name result = new Name();
			assertNotNull(result);
			result = null; // Resets the object "n" to null.
		}

	}

	@Nested	@DisplayName("toString() Test")
	@TestMethodOrder(OrderAnnotation.class)
	class ToStringTest {
		@Test @Order(2) @DisplayName("toString()")
		final void testToString() {
			/*
			 * Test the method toString.
			 */
			Name result = new Name("Zarko", "Milojevic", "Zoran");
			result.setSalutation("Mr.");
			String actualToString = result.toString();
			String expectedToString = "<myHealthCareSystem.Name>[first=Zarko, middle=Zoran, last=Milojevic, salutation=Mr.]";
			assertEquals(expectedToString, actualToString, "Inaccurate information.");
			result = null;
		}
	}

	@Nested	@DisplayName("formattedName() Test")
	@TestMethodOrder(OrderAnnotation.class)
	class FormattedName {
		@Test @Order(3) @DisplayName("formattedName()")
		final void testFormattedName() {
			/*
			 * Test the method formattedName.
			 */
			Name result = new Name("Zarko", "Milojevic", "Zoran");
			result.setSalutation("Mr.");
			String expectedValue = "Mr. Zarko Zoran Milojevic";
			String actualValue = result.formattedName();
			assertEquals(expectedValue, actualValue, "Inaccurate information.");
			result = null;
		}

	}

	@Nested	@DisplayName("setFirst() Test")
	@TestMethodOrder(OrderAnnotation.class)
	class SetFirstTest {
		@Test @Order(4) @DisplayName("setFirst()")
		final void testSetFirst() {
			/*
			 * Test the method setFirst.
			 */
			Name result = new Name();
			result.setFirst("Zarko");
			String expectedValue = "Zarko";
			String actualValue = result.getFirst();
			assertEquals(expectedValue, actualValue, "Inaccurate information.");
			result = null;
		}	
	}

	@Nested	@DisplayName("setLast() Test")
	@TestMethodOrder(OrderAnnotation.class)
	class SetLastTest {
		@Test @Order(5) @DisplayName("setLast()")
		final void testSetLast() {
			/*
			 * Test the method setLast.
			 */
			Name result = new Name();
			result.setLast("Milojevic");
			String expectedValue = "Milojevic";
			String actualValue = result.getLast();
			assertEquals(expectedValue, actualValue, "Inaccurate information.");
			result = null;
		}	
	}

	@Nested	@DisplayName("setMiddle() Test")
	@TestMethodOrder(OrderAnnotation.class)
	class SetMiddleTest {
		@Test @Order(6) @DisplayName("setMiddle()")
		final void testMiddle() {
			/*
			 * Test the method setMiddle.
			 */
			Name result = new Name();
			result.setMiddle("Zoran");
			String expectedValue = "Zoran";
			String actualValue = result.getMiddle();
			assertEquals(expectedValue, actualValue, "Inaccurate information.");
			result = null;
		}	
	}


	@Nested	@DisplayName("setSalutation() Test")
	@TestMethodOrder(OrderAnnotation.class)
	class SetSalutationTest {
		@Test @Order(7) @DisplayName("setSalutation()")
		final void testSetSalutation() {
			/*
			 * Test the method setSalutation.
			 */
			Name result = new Name();
			result.setSalutation("Mr.");
			String expectedValue = "Mr.";
			String actualValue = result.getSalutation();
			assertEquals(expectedValue, actualValue, "Inaccurate information.");
			result = null;
		}
	}


	@Nested	@DisplayName("first() Test")
	@TestMethodOrder(OrderAnnotation.class)
	class FirstTest {
		@Test @Order(8) @DisplayName("first()")
		final void testFirst() {
			/*
			 * Test the method for the getFirst.
			 */
			Name result = new Name();
			result.setFirst("Zarko");
			String expectedValue = "Zarko";
			String actualValue = result.getFirst();
			assertEquals(expectedValue, actualValue, "Inaccurate information.");
			result = null;
		}
	}


	@Nested	@DisplayName("last() Test")
	@TestMethodOrder(OrderAnnotation.class)
	class LastTest {
		@Test @Order(9) @DisplayName("last()")
		final void testlast() {
			/*
			 * Test for the method getLast.
			 */
			Name result = new Name();
			result.setLast("Milojevic");
			String expectedValue = "Milojevic";
			String actualValue = result.getLast();
			assertEquals(expectedValue, actualValue, "Inaccurate information.");
			result = null;
		}
	}


}
