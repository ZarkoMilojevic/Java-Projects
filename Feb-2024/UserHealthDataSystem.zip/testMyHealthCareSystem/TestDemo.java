package testMyHealthCareSystem;

import myHealthCareSystem.*;

/**
 * Main class for testing the whole program.
 * Uses JUnit version 5
 * Lab Professor: Natalie Gluzman
 * Due Date: March 07, 2024
 * @description: Assignment 01
 * @author	Zarko Milojevic, ID 041113810
 * @version 21.0.1 2023-10-17 LTS
 * @see 	Java(TM) SE Runtime Environment (build 21.0.1+12-LTS-29) 
 */

public class TestDemo {

	public static void main(String[] args) {
		// Initialize and declare the main objects, give random parameters.

		Name patientName = new Name ("Zarko Milojevic"); // Class Name, first, last, middle, salutation
		Address addressName = new Address ("Atinska",  "85/15", "Kragujevac", "Serbia", "34000"); // Class Address, Street, no, city, postal code
		BirthDate anyDate = new BirthDate (1986, 06, 19); // Class BirthDate, Year, month, day
		EMRecord newData = new EMRecord ("Ontario", "1986", "19", "25"); // Class EMRecord, FacilityProvince, birthdate, chartno, healthno

		// Setting random values for height, weight, name, and address from the class EMRecord.
		newData.setHeight(182);
		newData.setWeight(82);
		newData.setName(patientName);
		newData.setAddress(addressName);

		// Calling value for the class BMI Record
		newData.bmi();

		// Setting random values for all variables from the class EMRecord (as extended from EMHRecord) except 4 defined above - Name, Address, BirthDate, EMRecord. 
		newData.setFunctionalCentreAccount("Some Value 55");
		newData.setInstitutionNumber("3");
		newData.setEncounterSequence(10);
		newData.setIssuingProvince("Ontario");
		newData.setResidenceCode("68");
		newData.setGender("Male");
		newData.setSubmissionYear(2024);
		newData.setAdminViaAmbulance("Injured");
		newData.setRegistrationDate(20240403);
		newData.setRegistrationTime(1147);
		newData.setBirthDate(anyDate); // Calling from the above.

		// Print out results.

		System.out.printf("Information about the patient:\n");
		System.out.printf("Patient's Full Name: %s\n",newData.formattedName());
		System.out.printf("Patient's Address: %s\n", newData.formattedAddress());
		System.out.printf("Patient's Height and Weight: %scm, %skg\n", newData.getHeight(),newData.getWeight());
		System.out.printf("Patient's Functional Centre Account: %s\n", newData.getFunctionalCentreAccount());
		System.out.printf("Patient's Encounter Sequence: %s\n", newData.getEncounterSequence());
		System.out.printf("Patient's Issuing Province: %s\n",newData.getIssuingProvince());
		System.out.printf("Patient's Residence Code: %s\n",newData.getResidenceCode());
		System.out.printf("Patient's Gender: %s\n",newData.getGender());
		System.out.printf("Patient's Submission Year: %s\n",newData.getSubmissionYear());
		System.out.printf("Patient's Registration Date and Time: %s, %s\n",newData.getRegistrationDate(),newData.getRegistrationTime());
		System.out.printf("Patient's Birthday: %s\n",newData.getBirthDate());

		// Calculates and prints the BMI for the patient record
		double patientBMI = MedicalCalculator.calculateBMI(newData.getWeight(),newData.getHeight());
		System.out.printf("BMI of patientNew: %s\n",newData.bmi());

		// Displays BMI value ranges
		System.out.print("----------------------------------------------------------------------------");
		System.out.println("\nBMI VALUES");
		System.out.println("Underweight: less than 18.5");
		System.out.println("Normal:      between 18.5 and 24.9");
		System.out.println("Overweight:  between 25 and 29.9");
		System.out.println("Obese:       30 or greater");
		System.out.println("Program by Zarko Milojevic");



	}

}
