package testMyHealthCareSystem;


/*		@(#)BirthDate_Test.java	Jan. 31, 2024
 *
 */


import static org.junit.jupiter.api.Assertions.*;


import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

import myHealthCareSystem.*;


/**
 * This class tests BirthDate class.
 * Lab Professor: Natalie Gluzman
 * Due Date: Mar 07, 2024
 * @description: Assignment 01
 * @author	Zarko Milojevic, ID 041113810
 * @version 21.0.1 2023-10-17 LTS
 * @see 	Java(TM) SE Runtime Environment (build 21.0.1+12-LTS-29)
 */

@DisplayName("Test My HealthCare Application Domain - BirthDate")
@TestMethodOrder(OrderAnnotation.class)
public class BirthDate_Test {

	BirthDate b; 

	@BeforeEach
	void setUp() throws Exception {
		/*
		 * Initialize the object prior to test commencing.
		 */
		b = new BirthDate(2024,02,14);
	}

	@AfterEach
	void tearDown() throws Exception {
		/*
		 *	Reset the result of previous test.
		 */
		b = null;
	}

	/*		Methods to test
	 * 
		+BirthDate(day:int, month:int, year:int)
		+toString():String
		+formattedBirthDate():String
		+getDay():int
		+getMonth():int
		+getYear():int
	 */


	@Nested	@DisplayName("BirthDate() Test")
	@TestMethodOrder(OrderAnnotation.class)
	class BirthDateTest {
		@Test @Order(1) @DisplayName("BirthDate() test with Null arguments")
		final void testBirthDateWithNullArguments() {
			BirthDate result = new BirthDate(0,0,0);
			assertNotNull(result);
			result = null;
		}

		/*
		 * Test for the constructor with given arguments.
		 */
		@Test
		@Order(2)
		@DisplayName("Constructor with valid arguments")
		final void testConstructorWithValidArguments() {
			BirthDate result = new BirthDate(1999, 12, 13);
			assertNotNull(result);
			assertEquals(1999, result.getYear());
			assertEquals(12, result.getMonth());
			assertEquals(13, result.getDay());
			result = null;
		}
	}

	@Nested	@DisplayName("toString() Test")
	@TestMethodOrder(OrderAnnotation.class)
	class ToStringTest {
		@Test @Order(3) @DisplayName("toString()")
		final void testToString() {
			/*
			 * Test for the method toString. 
			 */
			BirthDate result = new BirthDate(1999, 12, 13);
			assertEquals("<myHealthCareSystem.BirthDate>[year=1999, month=12, day=13]", result.toString(),"Inaccurate information.");
			result = null;
		}
	}


	@Nested	@DisplayName("formattedBirthDate() Test")
	@TestMethodOrder(OrderAnnotation.class)
	class FormattedBirthDate {
		@Test @Order(4) @DisplayName("formattedBirthDate()")
		final void testFormattedBirthDate() {
			/*
			 * Test for the method formattedBirthDate.
			 */
			BirthDate result = new BirthDate(1986,6,19);
			String expectedValue = "1986/6/19";
			String actualValue = result.formattedBirthDate();
			assertEquals(expectedValue,actualValue,"Inaccurate information.");
			result = null;
		}

	}

	@Nested	@DisplayName("getDay() Test")
	@TestMethodOrder(OrderAnnotation.class)
	class GetDayTest {
		@Test @Order(5) @DisplayName("getDay()")
		final void testGetDay() {
			/*
			 * Test for the method getDay.
			 */
			BirthDate result = new BirthDate(1999,12,13);
			int expectedValue = 13;
			int actualValue = result.getDay();
			assertEquals(expectedValue,actualValue,"Inaccurate information.");
			result = null;
		}	
	}

	@Nested	@DisplayName("getMonth() Test")
	@TestMethodOrder(OrderAnnotation.class)
	class GetMonthTest {
		@Test @Order(6) @DisplayName("getMonth()")
		final void testGetMonth() {
			/*
			 * Test for the method getMonth.
			 */
			BirthDate result = new BirthDate(1999,12,13);
			int expectedValue = 12;
			int actualValue = result.getMonth();
			assertEquals(expectedValue,actualValue,"Inaccurate information.");
			result = null;
		}	
	}

	@Nested	@DisplayName("getYear() Test")
	@TestMethodOrder(OrderAnnotation.class)
	class GetYearTest {
		@Test @Order(7) @DisplayName("getYear()")
		final void testGetYear() {
			/*
			 * Test for the method getYear.
			 */
			BirthDate result = new BirthDate(1999,12,13);
			int expectedValue = 1999;
			int actualValue = result.getYear();
			assertEquals(expectedValue,actualValue,"Inaccurate information.");
			result = null;
		}	
	}
}
