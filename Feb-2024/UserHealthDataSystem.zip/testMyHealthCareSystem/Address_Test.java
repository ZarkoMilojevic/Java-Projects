package testMyHealthCareSystem;


/*		@(#)Address_Test.java	Jan. 31, 2024
 *
 */


import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

import myHealthCareSystem.Address;


/**
 * Test class for testing the Address class
 * Uses JUnit version 5
 * Lab Professor: Natalie Gluzman
 * Due Date: Mar 07, 2024
 * @description: Assignment 01
 * @author	Zarko Milojevic, ID 041113810
 * @version 21.0.1 2023-10-17 LTS
 * @see 	Java(TM) SE Runtime Environment (build 21.0.1+12-LTS-29) 
 */
@DisplayName("Test My HealthCare Application Domain - Address")
@TestMethodOrder(OrderAnnotation.class)
public class Address_Test {

	Address a;

	@BeforeEach
	void setUp() throws Exception {
		/*
		 * Initialize the object prior to test commencing.
		 */
		a = new Address();
	}

	@AfterEach
	void tearDown() throws Exception {
		/*
		 *	Reset the result of previous test.
		 */
		a = null;
	}

	/*		Methods to test
	 * 
	 * 	+Address(...)
			+formattedAddress():String
			+street():String
			+postalCode():String
			+getCity():String
			+setStreet(street:String):void
			+setNumber(number:String):void
			+setCity(city:String):void
			+setCountry(country:String):void
			+setPostalCode(postalCode:String):void
	 */

	@Nested	@DisplayName("Address() Test")
	@TestMethodOrder(OrderAnnotation.class)
	class AddressTest {
		@Test @Order(1) @DisplayName("Address() test with Null arguments")
		final void testAddressWithNullArguments() {
			Address result = new Address();
			assertNotNull(result);
			result = null; // Resets the object "a" to null.
		}	
		@Test @Order(2) @DisplayName("Address() test with arguments")
		final void testAddressWithOverloadedConstructor() {
			Address result = new Address("Woodroffe Avenue", "1385", "Ottawa", "K2G1V8", "Canada");
			assertEquals("Woodroffe Avenue", result.getStreet());
			assertEquals("1385", result.getNumber());
			assertEquals("Ottawa", result.getCity());
			assertEquals("K2G1V8", result.getPostalCode());
			assertEquals("Canada", result.getCountry());
			result = null; // Reset to null.	
		}

	}

	@Nested	@DisplayName("toString() Test")
	@TestMethodOrder(OrderAnnotation.class)
	class ToStringTest {
		@Test @Order(3) @DisplayName("toString()")
		final void testToString() {
			/*
			 * Test the method toString.
			 */
			Address result = new Address ("Woodroffe Avenue", "1385", "Ottawa", "K2G1V8", "Canada");
			assertEquals ("<myHealthCareSystem.Address>[street=Woodroffe Avenue, number=1385, city=Ottawa, postal code=K2G1V8, country=Canada]",result.toString());
			result = null;
		}
	}

	@Nested	@DisplayName("formattedAddress() Test")
	@TestMethodOrder(OrderAnnotation.class)
	class FormattedAddress {
		@Test @Order(4) @DisplayName("formattedAddress()")
		final void testFormattedAddress() {
			/*
			 * Test the method formattedAddress.
			 */
			Address result = new Address ("Woodroffe Avenue", "1385", "Ottawa", "K2G1V8", "Canada");
			String expectedValue = "Woodroffe Avenue,1385,Ottawa,K2G1V8,Canada";
			String actualValue = result.formattedAddress();
			assertEquals(expectedValue,actualValue, "Inaccurate information.");
			result = null;
		}

	}

	@Nested	@DisplayName("postalCode() Test")
	@TestMethodOrder(OrderAnnotation.class)
	class PostalCodeTest {
		@Test @Order(5) @DisplayName("postalCode()")
		final void testPostalCode() {
			/*
			 * Test the method postalCode.
			 */
			Address result = new Address();
			result.setPostalCode("K2G1V8");
			String expectedValue = "K2G1V8";
			String actualValue = result.getPostalCode();
			assertEquals(expectedValue, actualValue, "Inaccurate information.");
			result = null;
		}	
	}

	@Nested	@DisplayName("getCity() Test")
	@TestMethodOrder(OrderAnnotation.class)
	class GetCityTest {
		@Test @Order(6) @DisplayName("getCity()")
		final void testGetCity() {
			/*
			 * Test the method getCity.
			 */
			Address result = new Address();
			result.setCity("Ottawa");
			String expectedValue = "Ottawa";
			String actualValue = result.getCity();
			assertEquals(expectedValue, actualValue, "Inaccurate information.");
			result = null;
		}	
	}


	@Nested	@DisplayName("setStreet() Test")
	@TestMethodOrder(OrderAnnotation.class)
	class SetStreetTest {
		@Test @Order(7) @DisplayName("setStreet()")
		final void testSetStreet() {
			/*
			 * Test the method setStreet.
			 */
			Address result = new Address();
			result.setStreet("Woodroffe Avenue");
			String expectedValue = "Woodroffe Avenue";
			String actualValue = result.getStreet();
			assertEquals(expectedValue, actualValue, "Inaccurate information.");
			result = null;		
		}
	}

	@Nested	@DisplayName("setNumber() Test")
	@TestMethodOrder(OrderAnnotation.class)
	class SetNumberTest {
		@Test @Order(8) @DisplayName("setNumber()")
		final void testSetNumber() {
			/*
			 * Test the method setNumber.
			 */
			Address result = new Address();
			result.setNumber("1385");
			String expectedValue = "1385";
			String actualValue = result.getNumber();
			assertEquals(expectedValue, actualValue, "Inaccurate information.");
			result = null;
		}
	}


	@Nested	@DisplayName("setCity() Test")
	@TestMethodOrder(OrderAnnotation.class)
	class SetCityTest {
		@Test @Order(9) @DisplayName("setCity()")
		final void testSetCity() {
			/*
			 * Test the method setCity.
			 */
			Address result = new Address();
			result.setCity("Ottawa");
			String expectedValue = "Ottawa";
			String actualValue = result.getCity();
			assertEquals(expectedValue, actualValue, "Inaccurate information.");
			result = null;

		}
	}

	@Nested	@DisplayName("setCountry() Test")
	@TestMethodOrder(OrderAnnotation.class)
	class SetCountryTest {
		@Test @Order(10) @DisplayName("setCountry()")
		final void testSetCountry() {
			/*
			 * Test the method setCountry.
			 */
			Address result = new Address();
			result.setCountry("Canada");
			String expectedValue = "Canada";
			String actualValue = result.getCountry();
			assertEquals(expectedValue, actualValue, "Inaccurate information.");
			result = null;
		}
	}

	@Nested	@DisplayName("setPostalCode() Test")
	@TestMethodOrder(OrderAnnotation.class)
	class SetPostalCodeTest {
		@Test @Order(11) @DisplayName("setPostalCode()")
		final void testSetCountry() {
			/*
			 * Test the method setPostalCode.
			 */
			Address result = new Address();
			result.setPostalCode("K2G1V8");
			String expectedValue = "K2G1V8";
			String actualValue = result.getPostalCode();
			assertEquals(expectedValue, actualValue, "Inaccurate information.");
			result = null;	
		}
	}



}
