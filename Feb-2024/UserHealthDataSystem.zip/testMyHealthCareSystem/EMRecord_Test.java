package testMyHealthCareSystem;


/*		@(#)EMRecord_Test.java	Jan. 31, 2024
 *
 */


import static org.junit.jupiter.api.Assertions.*;


import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

import myHealthCareSystem.*;

/**
 * Test class for EMRecord class.
 * Lab Professor: Natalie Gluzman
 * Due Date: Mar 07, 2024
 * @description: Assignment 01
 * @author	Zarko Milojevic, ID 041113810
 * @version 21.0.1 2023-10-17 LTS
 * @see 	Java(TM) SE Runtime Environment (build 21.0.1+12-LTS-29)
 */

@DisplayName("Test My HealthCare Application Domain - EMRecord")
@TestMethodOrder(OrderAnnotation.class)
public class EMRecord_Test {

	EMRecord emr;

	@BeforeEach
	void setUp() throws Exception {

		emr = new EMRecord (null, null, null, null);
	}

	@AfterEach
	void tearDown() throws Exception {

		emr = null;
	}

	/*		Methods to test
	 * 
		+EMRecord(reportingFacilityProvince:String, institutionNumber:String, chartNumber:String,healthCareNumber:String)
		+toString():String
		+setName(name:Name):void
		+setAddress(address:Address):void
		+setHeight():void
		+getHeight():int
		+setWeight():void
		+getWeight():int
		+formattedName():String
		+formattedAddress():String
		+bmi():int
	 */


	@Nested	@DisplayName("EMRecord() Test")
	@TestMethodOrder(OrderAnnotation.class)
	class EMRecordTest {
		@Test @Order(1) @DisplayName("EMRecord() test with Null arguments")
		final void testEMRecordWithNullArguments() {
			/*
			 * Test the default constructor with no arguments.
			 */
			EMRecord result = null;
			assertNull(result);
			result = null;
		}
	}
	class EMRecordOverloadedTest {
		@Test @Order(2) @DisplayName("EMRecord() test with arguments")
		final void testEMRecordWithOverloadedConstructor() {
			/*
			 * Test the parameterized constructor with arguments.
			 */
			EMRecord result = new EMRecord("Ontario", "10", "5", "Test10");
			assertEquals("Ontario", result.getReportingFacilityProvince());
			assertEquals("10", result.getInstitutionNumber());
			assertEquals("5", result.getChartNumber());
			assertEquals("Test10", result.getHealthCareNumber());
			result = null; // Reset to null.	
		}
	}

	@Nested	@DisplayName("getHeight() Test")
	@TestMethodOrder(OrderAnnotation.class)
	class GetHeightTest {
		@Test @Order(3) @DisplayName("getHeight()")
		final void testGetHeight() {
			/*
			 * Test the method getHeight.
			 */
			EMRecord result = new EMRecord();
			result.setHeight(182);
			double expectedValue = 182;
			double actualValue = result.getHeight();
			assertEquals(expectedValue, actualValue, "Inaccurate information.");
			result = null;

		}
	}
	@Nested	@DisplayName("setHeight() Test")
	@TestMethodOrder(OrderAnnotation.class)
	class SetHeightTest {
		@Test @Order(4) @DisplayName("setHeight()")
		final void testSetHeight() {
			/*
			 * Test the method setHeight.
			 */
			EMRecord result = new EMRecord();
			result.setHeight(182);
			double expectedValue = 182;
			double actualValue = result.getHeight();
			assertEquals(expectedValue, actualValue, "Inaccurate information.");
			result = null;

		}
	}
	@Nested	@DisplayName("getWeight() Test")
	@TestMethodOrder(OrderAnnotation.class)
	class getWeightTest {
		@Test @Order(5) @DisplayName("getWeight()")
		final void testGetWeight() {
			/*
			 * Test the method getWeight.
			 */
			EMRecord result = new EMRecord();
			result.setWeight(82);
			double expectedValue = 82;
			double actualValue = result.getWeight();
			assertEquals(expectedValue, actualValue, "Inaccurate information.");
			result = null;

		}
	}
	@Nested	@DisplayName("setWeight() Test")
	@TestMethodOrder(OrderAnnotation.class)
	class setWeightTest {
		@Test @Order(6) @DisplayName("setWeight()")
		final void testSetWeight() {
			/*
			 * Test the method setWeight.
			 */
			EMRecord result = new EMRecord();
			result.setWeight(82);
			double expectedValue = 82;
			double actualValue = result.getWeight();
			assertEquals(expectedValue, actualValue, "Inaccurate information.");
			result = null;

		}
	}
	@Nested	@DisplayName("toString() Test")
	@TestMethodOrder(OrderAnnotation.class)
	class ToStringTest {
		@Test @Order(7) @DisplayName("toString()")
		final void testToString() {
			/*
			 * Test for the toString method.
			 */
			EMRecord result = new EMRecord(null, null, null, null);
			System.out.println(result.toString());
			String expectedString = "<myHealthCareSystem.EMRecord>[height=0, weight=0, name=null, address=null]";
			String actualString = result.toString();
			assertEquals(expectedString, actualString,"Inaccurate information.");
			result = null;
		}
	}

	@Nested    @DisplayName("Submission Year Test")
	@TestMethodOrder(OrderAnnotation.class)
	class SubmissionYearTest {
		/*
		 * Test for the method setSubmissionYear().
		 */

		@Test @Order(8) @DisplayName("setSubmissionYear()")
		final void testSetSubmissionYear() {
			EMRecord result = new EMRecord(null, null, null, null);
			result.setSubmissionYear(2023);
			int expectedValue = 2023;
			int actualValue = result.getSubmissionYear();
			assertEquals(expectedValue,actualValue,"Inaccurate information.");
			result = null;
		}   
	}
	/*
	 * Test for the method getSubmissionYear().
	 */
	@Test @Order(9) @DisplayName("getSubmissionYear()")
	final void testGetSubmissionYear() {
		EMRecord result = new EMRecord(null, null, null, null);
		result.setSubmissionYear(2023);
		int expectedValue = 2023;
		int actualValue = result.getSubmissionYear();
		assertEquals(expectedValue,actualValue,"Inaccurate information.");
		result = null;
	}

	/*
	 * Test for the method BMI().
	 */
	@Test @Order(10) @DisplayName("BMI()")
	final void testBMI() {
		EMRecord result = new EMRecord();
		result.setSubmissionYear(2023);
		int expectedValue = 2023;
		int actualValue = result.getSubmissionYear();
		assertEquals(expectedValue,actualValue,"Inaccurate information.");
	}
}

