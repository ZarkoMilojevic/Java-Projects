package testMyHealthCareSystem;


/*		@(#)EMHRecord_Test.java	Jan. 31, 2024
 *
 */


import static org.junit.jupiter.api.Assertions.*;


import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

import myHealthCareSystem.*;


/**
 * This is test for the class EMHRecord.
 * Lab Professor: Natalie Gluzman
 * Due Date: Mar 07, 2024
 * @description: Assignment 01
 * @author	Zarko Milojevic, ID 041113810
 * @version 21.0.1 2023-10-17 LTS
 * @see 	Java(TM) SE Runtime Environment (build 21.0.1+12-LTS-29)
 */

@DisplayName("Test My HealthCare Application Domain - EMHRecord")
@TestMethodOrder(OrderAnnotation.class)
public class EMHRecord_Test {

	EMHRecord emhr;

	@BeforeEach
	void setUp() throws Exception {

		emhr = new EMHRecord(null, null, null, null);
	}

	@AfterEach
	void tearDown() throws Exception {

		emhr = null;
	}

	/*		Methods to test
	 * 
		+EMHRecord(reportingFacilityProvince:String, institutionNumber:String, chartNumber:String,healthCareNumber:String)
		+toString():String
	 */


	@Nested	@DisplayName("EMHRecord() Test")
	@TestMethodOrder(OrderAnnotation.class)
	class EMHRecordTest {
		@Test @Order(1) @DisplayName("EMHRecord() test with Null arguments")
		final void testEMHRecordWithNullArguments() {
			/*
			 * Test the default constructor without arguments.
			 */
			EMHRecord result = null;
			assertNull(result);
		}

		/*
		 * Test the constructor with arguments.
		 */
		@Test @Order(2) @DisplayName("EMHRecord() test with Valid arguments")
		final void testEMHRecordWithValidArguments() {
			EMHRecord result = new EMHRecord("Ontario", "10", "5", "Test10");
			assertNotNull(result,"Inaccurate information.");
			result = null;
		}
	}

	@Nested	@DisplayName("toString() Test")
	@TestMethodOrder(OrderAnnotation.class)
	class ToStringTest {
		@Test @Order(3) @DisplayName("toString()")
		final void testToString() {
			/*
			 * Test toString method.
			 */
			EMHRecord result = new EMHRecord(null, null, null, null);
			String expected = "<myHealthCareSystem.EMHRecord>[reportingFacilityProvince=null, institutionNumber=null, functionalCentreAccount=null, encounterSequence=0, healthCareNumber=null, chartNumber=null, issuingProvince=null, residenceCode=null, gender=null, submissionYear=0, adminViaAmbulance=null, registrationDate=0, registrationTime=0, birthDate=null]";
			String actual = result.toString();
			assertEquals(expected, actual ,result.toString());
			result = null;
		}
	}

	/*
	 * Testing setAdminViaAmbulance() and getAdminViaAmbulance() methods.
	 */
	@Nested    @DisplayName("AdminViaAmbulance Test")
	@TestMethodOrder(OrderAnnotation.class)
	class AdminViaAmbulanceTest {
		@Test @Order(4) @DisplayName("setAdminViaAmbulance()")
		final void testSetAdminViaAmbulance() {
			EMHRecord result = new EMHRecord(null, null, null, null);
			result.setAdminViaAmbulance("Injured");
			String expectedValue = "Injured";
			String actualValue = result.getAdminViaAmbulance();
			assertEquals(expectedValue,actualValue,"Inaccurate information.");
			result = null;
		}   

		@Test @Order(5) @DisplayName("getAdminViaAmbulance()")
		final void testGetAdminViaAmbulance() {
			EMHRecord result = new EMHRecord(null, null, null, null);
			result.setAdminViaAmbulance("Injured");
			String expectedValue = "Injured";
			String actualValue = result.getAdminViaAmbulance();
			assertEquals(expectedValue,actualValue,"Inaccurate information.");
			result = null;
		}   
	}

}
