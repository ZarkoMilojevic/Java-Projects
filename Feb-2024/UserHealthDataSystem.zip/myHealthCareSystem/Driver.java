package myHealthCareSystem;

import java.util.Scanner;

/**
 * Main class to run the whole program and displays results.
 * Uses JUnit version 5
 * Lab Professor: Natalie Gluzman
 * Due Date: March 07, 2024
 * @description: Assignment 01
 * @author	Zarko Milojevic, ID 041113810
 * @version 21.0.1 2023-10-17 LTS
 * @see 	Java(TM) SE Runtime Environment (build 21.0.1+12-LTS-29) 
 */

public class Driver {

	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);

		// Insert data about patient`s name.

		System.out.println("Enter patient's first name:");
		String firstName = scanner.nextLine();
		System.out.println("Enter patient's last name:");
		String lastName = scanner.nextLine();
		System.out.println("Enter patient's middle name:");
		String middleName = scanner.nextLine();
		Name patientName = new Name(firstName, lastName, middleName);

		// Insert data about patient`s address.

		System.out.println("Enter patient's street:");
		String street = scanner.nextLine();
		System.out.println("Enter patient's street number:");
		String streetNumber = scanner.nextLine();
		System.out.println("Enter patient's city:");
		String city = scanner.nextLine();
		System.out.println("Enter patient's country:");
		String country = scanner.nextLine();
		System.out.println("Enter patient's postal code:");
		String postalCode = scanner.nextLine();
		Address patientAddress = new Address(street, streetNumber, city, country, postalCode);

		// Insert the birthdate of the patient.

		System.out.println("Enter patient's birth year:");
		int birthYear = scanner.nextInt();
		System.out.println("Enter patient's birth month:");
		int birthMonth = scanner.nextInt();
		System.out.println("Enter patient's birth day:");
		int birthDay = scanner.nextInt();
		BirthDate patientBirthDate = new BirthDate(birthYear, birthMonth, birthDay);

		// Insert height and weight of the patient.

		System.out.println("Enter patient's height (cm):");
		int height = scanner.nextInt();
		System.out.println("Enter patient's weight (kg):");
		int weight = scanner.nextInt();

		// Create an EMRecord object using patient`s information.

		EMRecord patientRecord = new EMRecord("", "", "", "");
		patientRecord.setName(patientName);
		patientRecord.setAddress(patientAddress);
		patientRecord.setBirthDate(patientBirthDate);
		patientRecord.setHeight(height);
		patientRecord.setWeight(weight);

		// Display patient information.

		System.out.println("Information about the patient:");
		System.out.println("Patient's Full Name: " + patientRecord.formattedName());
		System.out.println("Patient's Address: " + patientRecord.formattedAddress());
		System.out.println("Patient's Height and Weight: " + height + "cm, " + weight + "kg");

		// Calculate and display BMI
		double bmi = patientRecord.bmi();
		System.out.println("BMI of patient: " + bmi);

		// Display BMI value ranges
		System.out.println("----------------------------------------------------------------------------");
		System.out.println("BMI VALUES");
		System.out.println("Underweight: less than 18.5");
		System.out.println("Normal:      between 18.5 and 24.9");
		System.out.println("Overweight:  between 25 and 29.9");
		System.out.println("Obese:       30 or greater");
		System.out.println("Program by Zarko Milojevic");

		scanner.close();
	}

}
