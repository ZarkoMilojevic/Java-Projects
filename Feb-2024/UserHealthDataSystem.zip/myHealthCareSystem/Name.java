package myHealthCareSystem;

/**
 * This class collects the name of the patient.
 * Lab Professor: Natalie Gluzman
 * Due Date: Mar 07, 2024
 * @description: Assignment 01
 * @author	Zarko Milojevic, ID 041113810
 * @version 21.0.1 2023-10-17 LTS
 * @see 	Java(TM) SE Runtime Environment (build 21.0.1+12-LTS-29)
 */
public class Name {


	/*	Attributes			************************************/

	private String first;
	private String last;
	private String middle;
	private String salutation;

	/*	Constructors		************************************/
	/**
	 * Default constructor to initialize the object Name, no parameters.
	 */
	public Name() {
		first = "";
		last = "";
		middle = "";
		salutation = "";
	}

	/**
	 * Constructor that sets the name using one string containing both names.
	 * @param name is a string containing multiple parts of the full name (first, last, salutation, middle).
	 * @return name will be shown as a result. 
	 */		
	public Name(String name) {

		if (name.contains(",")) {
			String[] nameMultiple = name.split(",");
			if (nameMultiple.length == 2) {
				String lastName = nameMultiple[0].trim();
				String firstName = nameMultiple[1].trim();
				first = firstName;
				last = lastName;
				middle = "";
				salutation = "";
			}
		}
		else{
			String[] nameMultiple = name.split(" ");
			if (nameMultiple.length == 2) {
				first = nameMultiple[0].trim();
				last = nameMultiple[1].trim();
				middle = "";
				salutation = "";
			}
		}
		
	}

	/**
	 * Constructor that sets first and last name.
	 * @param first
	 * @param last
	 */
	public Name(String first, String last) {
		this.first = first;
		this.last = last;
	}

	/**
	 * Constructor that sets first, last, and middle name.
	 * @param first
	 * @param last
	 * @param middle
	 */
	public Name(String first, String last, String middle) {
		this.first = first;
		this.last = last;
		this.middle = middle;
	}


	/*	Accessors			************************************/


	/**
	 * Accessor for the first name.
	 * @return first
	 */
	public String getFirst() {
		return first;
	}

	/**
	 * Accessor for the last name.
	 * @return last
	 */
	public String getLast() {
		return last;
	}		

	/**
	 * Accessor for the middle name.
	 * @return middle
	 */
	public String getMiddle() {
		return middle;
	}

	/**
	 * Accessor for the salutation.
	 * @return salutation
	 */
	public String getSalutation() {
		return salutation;
	}

	/* Modifiers			************************************/

	/**
	 * Mutator that sets the first name.
	 * @param first
	 */	
	public void setFirst(String first) {
		this.first = first;
	}

	/**
	 * Mutator that sets the last name.
	 * @param last
	 */
	public void setLast(String last) {
		this.last = last;
	}

	/**
	 * Mutator that sets the middle name.
	 * @param middle
	 */
	public void setMiddle(String middle) {
		this.middle = middle;
	}

	/**
	 * Mutator that sets the salutation.
	 * @param salutation
	 */
	public void setSalutation(String salutation) {
		this.salutation = salutation;
	}


	/*	Normal Behavior	************************************/

	/**
	 * Method formats the name according to specifications of UML.
	 * Salutation is optional.
	 * @return specified name.
	 */		
	public String formattedName() {
		if (salutation == null) {
			return first + " " + middle + " " + last;
		} else {
			return salutation + " " + first + " " + middle + " " + last;
		}
	}


	/*	Helper Methods		************************************/

	/**
	 * To print out the complete object defined by constructor.
	 * @return string expression of object.
	 */
	public String toString() {
		return "<" + this.getClass().getName() + ">" + "[first=" + first + ", middle=" + middle + 
				", last=" + last + ", salutation=" + salutation + "]";
	}



}
