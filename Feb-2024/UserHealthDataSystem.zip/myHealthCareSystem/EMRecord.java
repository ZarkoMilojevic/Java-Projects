package myHealthCareSystem;

/*
 * 	W24	CST8284
 * 	Assignment 1: My Health System
 * 
 *		This is the start of a system which would maintain Electronic Medical Records for patients.
 *		This class assumes all values passed to the set methods are correct and valid.
 *		REVIEW THIS FILE, ASSIGNMENT INSTRUCTIONS, UML Class Diagram CAREFULLY BEFORE YOU START CODING!
 *
 * 	Remove unneeded comments/code when you are done. (Clean code is better code).
 * 
 * 	Field values and constraints can be found in the Standards guide
 *		Acute and Ambulatory Care Data Content Standard, https://secure.cihi.ca/estore/productSeries.htm?pc=PCC1428 (last searched January 27, 2024)
 * 
 */

/**
 * This class inherits attributes from EMRecord class.
 * Lab Professor: Natalie Gluzman
 * Due Date: Mar 07, 2024
 * @description: Assignment 01
 * @author	Zarko Milojevic, ID 041113810
 * @version 21.0.1 2023-10-17 LTS
 * @see 	Java(TM) SE Runtime Environment (build 21.0.1+12-LTS-29)
 */
public class EMRecord extends EMHRecord		{


	/*	Attributes added to the existing from parent class.	************************************/

	private int height;  
	private int weight;
	private Name name;
	private Address address;

	/*	Constructors		************************************/

	/**
	 * Default constructor without arguments.
	 */
	public EMRecord() {
		super();
	}

	/**
	 * Constructor with arguments to create the object.
	 * @param reportingFacilityProvince
	 * @param institutionNumber
	 * @param chartNumber
	 * @param healthCareNumber
	 * 
	 */
	public EMRecord(String reportingFacilityProvince, String institutionNumber, String chartNumber, String healthCareNumber) {
		super(reportingFacilityProvince, institutionNumber, chartNumber, healthCareNumber);
	}


	/*	Accessors			************************************/


	/** Accessor for attribute height.
	 * @return height
	 */
	public double getHeight() {
		return height;
	}

	/** Accessor for attribute weight.
	 * @return weight
	 */
	public double getWeight() {
		return weight;
	}


	/* Modifiers			************************************/


	/**
	 * Mutator that sets the name.
	 * @param name
	 */
	public void setName(Name name) {
		if (name != null) {
			this.name = name;
		}
	}

	/**
	 * Mutator that sets the address.
	 * @param address
	 */
	public void setAddress(Address address) {
		if (address != null) {
			this.address = address;
		}
	}

	/**
	 * Mutator that sets the height.
	 * @param height
	 */
	public void setHeight(int height) {
		this.height = height;
	}

	/**
	 * Mutator that sets the weight.
	 * @param weight
	 */
	public void setWeight(int weight) {
		this.weight = weight;
	}



	/*	Helper Methods		************************************/


	/**
	 * Method to return the data about patient in specified way (EMR object).
	 * @return string data
	 */
	public String toString() {
		return "<" + this.getClass().getName() + ">" + "[height=" + height + ", weight=" + weight + ", name=" + name + 
				", address=" + address + "]";
	}

	/**
	 * Method to display the name of the patient is a specified way.
	 * @return patient`s name as a string
	 */
	public String formattedName() {
		if (name != null) {
			return name.formattedName();
		} else {
			return "Name is not given.";
		}
	}

	/**
	 * Method to display the address of the patient is a specified way.
	 * @return patient`s address as a string
	 */
	public String formattedAddress() {
		if (address != null) {
			return address.formattedAddress();
		} else {
			return "Address is not given.";
		}

	}

	/**
	 * Method to calculate the Body Mass Index (BMI) of the patient.
	 * @return The BMI of the patient.
	 */
	public int bmi() {
		return (int) MedicalCalculator.calculateBMI(height, weight);
	}
}
