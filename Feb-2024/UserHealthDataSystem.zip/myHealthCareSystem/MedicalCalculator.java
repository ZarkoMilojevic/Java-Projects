package myHealthCareSystem;

/**
 * Class to apply calculations to specific type of EMR's and data.
 * Currently supports BMI (Body Mass Index) calculations.
 * Lab Professor: Natalie Gluzman
 * Due Date: Mar 07, 2024
 * @description: Assignment 01
 * @author	Zarko Milojevic, ID 041113810
 * @version 21.0.1 2023-10-17 LTS
 * @see 	Java(TM) SE Runtime Environment (build 21.0.1+12-LTS-29)
 */

import java.math.BigDecimal;
import java.math.RoundingMode;

public class MedicalCalculator {

	/**
	 * Default constructor for the object MedicalCalculator.
	 */
	private MedicalCalculator()	{
	}

	/**
	 * This method returns the calculated Body Mass Index (BMI) from data provided.
	 * @param weight Parameter Weight of the patient in pounds.
	 * @param height Parameter Height of the patient in inches.
	 * return calculated BMI.
	 */
	public static double calculateBMI(double weight, double height) {
		if (weight == 0 || height == 0) {
			return 0;
		} else {
			double bmi = (weight * 703) / (height * height);
			return round(bmi,1);	
		}
	}
	
	/**
	 * This method returns the incorrectly calculated Body Mass Index (BMI) from data provided.
	 * Weight is added to 703 instead of multiplied.
	 * @param weight Parameter Weight of the patient in pounds.
	 * @param height Parameter Height of the patient in inches.
	 * return calculated BMI.
	 */
	public static double incorrectlyCalculateBMI(double weight, double height) {
		if (weight == 0 || height == 0) {
			return 0;
		} else {
			double bmi = (weight + 703) / (height * height);
			return round(bmi,1);	
		}
	}

	/**
	 * This method rounds calculated value to a desired number of decimal places.
	 * @param unroundedBMI The calculated BMI value to be rounded.
	 * @param digits The number of decimal places to round to.
	 * @return roundedBMI.
	 */
	public static double round(double unroundedBMI, int digits) {
		if (digits < 0) {
			throw new IllegalArgumentException("Number of decimal digits cannot be negative");
		}
		double roundedBMI = 0;
		if (unroundedBMI != 0) {
			BigDecimal bd = BigDecimal.valueOf(unroundedBMI);
			bd = bd.setScale(digits, RoundingMode.HALF_UP);
			roundedBMI = bd.doubleValue();
		}
		return roundedBMI;
	}
	

	/**
	 * Main entry point for quick and dirty test purposes.
	 * @param args Command line arguments submitted thru the VM
	 */
	public static void main(String[] args) {
		System.out.println("BMI:" + calculateBMI(0, 0));
		System.out.println("BMI:" + calculateBMI(165, 0));
		System.out.println("BMI:" + calculateBMI(0, 69));
		System.out.println("BMI:" + calculateBMI(165, 69));
		System.out.println("BMI:" + calculateBMI(82, 182));

		System.out.println("\nBMI VALUES");
		System.out.println("Underweight: less than 18.5");
		System.out.println("Normal:      between 18.5 and 24.9");
		System.out.println("Overweight:  between 25 and 29.9");
		System.out.println("Obese:       30 or greater");

	}
}
