package myHealthCareSystem;

/**
 * TODO:	Document me
 */
public class Address {
	/*	TODO:	Implement the class based on the provided UML CLass diagram
	 * 		The class, methods, attributes must be documented using the javadoc comment format including appropriate @ tags
	 * 		e.g. @return, @param
	 */

	
	/*	Attributes			************************************/

	
	
	/*	Constructors		************************************/

	
	
	/*	Accessors			************************************/

	
	
	
	/* Modifiers			************************************/

	
	
	
	/*	Normal Behavior	************************************/

	
	
	
	
	/*	Helper Methods		************************************/
	


}
