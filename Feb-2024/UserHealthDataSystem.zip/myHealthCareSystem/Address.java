package myHealthCareSystem;

/**
 * This class collects address data about patient.
 * Lab Professor: Natalie Gluzman
 * Due Date: Mar 07, 2024
 * @description: Assignment 01
 * @author	Zarko Milojevic, ID 041113810
 * @version 21.0.1 2023-10-17 LTS
 * @see 	Java(TM) SE Runtime Environment (build 21.0.1+12-LTS-29)
 */
public class Address {


	/*	Attributes			************************************/

	private String street;
	private String number;
	private String city;
	private String postalCode;
	private String country;


	/*	Constructors		************************************/

	public Address() {

		// this (" ", " ", " ", " ", " "); Also possible like this.
		street = " ";
		number = " ";
		city = " ";
		postalCode = " ";
		country = " ";

	}


	public Address(String street, String number, String city, String postalCode, String country) {
		this.street = street;
		this.number = number;
		this.city = city;
		this.postalCode = postalCode;
		this.country = country;
	}

	/*	Accessors			************************************/

	
	/** Accessor for attribute Street.
	 * @return street
	 */
	public String getStreet() {
		return street;
	}

	/** Accessor for attribute number.
	 * @return number
	 */
	public String getNumber() {
		return number;
	}

	/** Accessor for attribute city.
	 * @return city
	 */
	public String getCity() {
		return city;
	}

	/** Accessor for attribute postalCode.
	 * @return postalCode
	 */
	public String getPostalCode() {
		return postalCode;
	}

	/** Accessor for attribute Country.
	 * @return country
	 */
	public String getCountry() {
		return country;
	}


	/* Modifiers			************************************/

	/**
	 * Mutator that sets the street.
	 * @param street
	 */	
	public void setStreet(String street) {
		this.street = street;
	}

	/**
	 * Mutator that sets the number.
	 * @param number
	 */	
	public void setNumber(String number) {
		this.number = number;
	}

	/**
	 * Mutator that sets the city.
	 * @param city
	 */
	public void setCity(String city) {
		this.city = city;
	}

	/**
	 * Mutator that sets the postalCode.
	 * @param postalCode
	 */
	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	/**
	 * Mutator that sets the country.
	 * @param country
	 */
	public void setCountry(String country) {
		this.country = country;
	}


	/*	Normal Behavior	************************************/

	/**
	 * Method that will return the address as a string in specified form.
	 * @return	address as a string.
	 */
	public String formattedAddress() {
		String formattedAddress = (street+","+number+","+city+","+postalCode+","+country);
		return formattedAddress;
	}


	/*	Helper Methods		************************************/

	/**
	 * Method toString will show the required output as a meaningful string.
	 * @return	This object as a string.
	 */
	public String toString() {
		return "<" + this.getClass().getName()+ ">" + "[street=" + street + ", number=" + number + 
				", city=" + city + ", postal code=" + postalCode + ", country=" + country + "]";
	}

}
