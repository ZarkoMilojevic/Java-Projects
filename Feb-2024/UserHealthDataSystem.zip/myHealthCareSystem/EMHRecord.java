package myHealthCareSystem;

/*
 * 	W24	CST8284
 * 	Assignment 1: My Health System
 * 
 *		This is the start of a system which would maintain Electronic Medical Records for patients.
 *		This class assumes all values passed to the set methods are correct and valid.
 *		REVIEW THIS FILE, ASSIGNMENT INSTRUCTIONS, UML Class Diagram CAREFULLY BEFORE YOU START CODING!
 *
 * 	Remove unneeded comments/code when you are done. (Clean code is better code).
 * 
 * 	Field values and constraints can be found in the Standards guide
 *		Acute and Ambulatory Care Data Content Standard, https://secure.cihi.ca/estore/productSeries.htm?pc=PCC1428 (last searched January 27, 2024).
 * 
 */


/**
 * This class maintain Electronic Medical Records for patients and assumes all values passed to the set methods are correct and valid.
 * Lab Professor: Natalie Gluzman
 * Due Date: Mar 07, 2024
 * @description: Assignment 01
 * @author	Zarko Milojevic, ID 041113810
 * @version 21.0.1 2023-10-17 LTS
 * @see 	Java(TM) SE Runtime Environment (build 21.0.1+12-LTS-29)
 */
public class EMHRecord {


	/* Attributes                                                 */

	private String reportingFacilityProvince;
	private String institutionNumber;
	private String functionalCentreAccount;
	private int encounterSequence;
	private String healthCareNumber;
	private String chartNumber;
	private String issuingProvince;
	private String residenceCode;
	private String gender;
	private int submissionYear;
	private String adminViaAmbulance;
	private int registrationDate;
	private int registrationTime;
	private BirthDate birthDate;

	// Contructor 

	/**
	 * Default constructor without arguments.
	 */
	public EMHRecord() {
	}

	/**
	 * Constructor build EMRecord object with basic attributes.
	 * @param reportingFacilityProvince
	 * @param institutionNumber
	 * @param healthCareNumber
	 * @param chartNumber
	 */
	public EMHRecord(String reportingFacilityProvince, String institutionNumber, String chartNumber, String healthCareNumber) {
		this.reportingFacilityProvince = reportingFacilityProvince;
		this.institutionNumber = institutionNumber;
		this.healthCareNumber = healthCareNumber;
		this.chartNumber = chartNumber;
	}


	/* Accessors                                                  */

	/** Accessor for attribute reportingFacilityProvince.
	 * @return reportingFacilityProvince
	 */
	public String getReportingFacilityProvince() {
		return reportingFacilityProvince;
	}

	/** Accessor for attribute institutionNumber.
	 * @return institutionNumber
	 */
	public String getInstitutionNumber() {
		return institutionNumber;
	}

	/** Accessor for attribute functionalCentreAccount.
	 * @return functionalCentreAccount
	 */
	public String getFunctionalCentreAccount() {
		return functionalCentreAccount;
	}

	/** Accessor for attribute encounterSequence.
	 * @return encounterSequence
	 */
	public int getEncounterSequence() {
		return encounterSequence;
	}

	/** Accessor for attribute healthCareNumber.
	 * @return healthCareNumber
	 */
	public String getHealthCareNumber() {
		return healthCareNumber;
	}

	/** Accessor for attribute chartNumber.
	 * @return chartNumber
	 */
	public String getChartNumber() {
		return chartNumber;
	}

	/** Accessor for attribute issuingProvince.
	 * @return issuingProvince
	 */
	public String getIssuingProvince() {
		return issuingProvince;
	}

	/** Accessor for attribute residenceCode.
	 * @return residenceCode
	 */
	public String getResidenceCode() {
		return residenceCode;
	}

	/** Accessor for attribute gender.
	 * @return gender
	 */
	public String getGender() {
		return gender;
	}

	/** Accessor for attribute submissionYear.
	 * @return submissionYear
	 */
	public int getSubmissionYear() {
		return submissionYear;
	}

	/** Accessor for attribute adminViaAmbulance.
	 * @return adminViaAmbulance
	 */
	public String getAdminViaAmbulance() {
		return adminViaAmbulance;
	}

	/** Accessor for attribute registrationDate.
	 * @return registrationDate
	 */
	public int getRegistrationDate() {
		return registrationDate;
	}

	/** Accessor for attribute registrationTime.
	 * @return registrationTime
	 */
	public int getRegistrationTime() {
		return registrationTime;
	}

	/** Accessor for attribute birthDate from the class BirthDate.
	 * @return birthDate
	 */
	public BirthDate getBirthDate() {
		return birthDate;
	}

	/* Mutators                                                    */


	/** Modifier for attribute reportingFacilityProvince.
	 * @param reportingFacilityProvince
	 */
	public void setReportingFacilityProvince(String reportingFacilityProvince) {
		this.reportingFacilityProvince = reportingFacilityProvince;
	}

	/** Modifier for attribute institutionNumber.
	 * @param institutionNumber
	 */
	public void setInstitutionNumber(String institutionNumber) {
		this.institutionNumber = institutionNumber;
	}

	/** Modifier for attribute functionalCentreAccount.
	 * @param functionalCentreAccount
	 */
	public void setFunctionalCentreAccount(String functionalCentreAccount) {
		this.functionalCentreAccount = functionalCentreAccount;
	}

	/** Modifier for attribute encounterSequence.
	 * @param encounterSequence
	 */
	public void setEncounterSequence(int encounterSequence) {
		this.encounterSequence = encounterSequence;
	}

	/** Modifier for attribute healthCareNumber.
	 * @param healthCareNumber
	 */
	public void setHealthCareNumber(String healthCareNumber) {
		this.healthCareNumber = healthCareNumber;
	}

	/** Modifier for attribute chartNumber.
	 * @param chartNumber
	 */
	public void setChartNumber(String chartNumber) {
		this.chartNumber = chartNumber;
	}

	/** Modifier for attribute issuingProvince.
	 * @param issuingProvince
	 */
	public void setIssuingProvince(String issuingProvince) {
		this.issuingProvince = issuingProvince;
	}

	/** Modifier for attribute residenceCode.
	 * @param residenceCode
	 */
	public void setResidenceCode(String residenceCode) {
		this.residenceCode = residenceCode;
	}

	/** Modifier for attribute gender.
	 * @param gender
	 */
	public void setGender(String gender) {
		this.gender = gender;
	}

	/** Modifier for attribute submissionYear.
	 * @param submissionYear
	 */
	public void setSubmissionYear(int submissionYear) {
		this.submissionYear = submissionYear;
	}

	/** Modifier for attribute adminViaAmbulance.
	 * @param adminViaAmbulance
	 */
	public void setAdminViaAmbulance(String adminViaAmbulance) {
		this.adminViaAmbulance = adminViaAmbulance;
	}

	/** Modifier for attribute registrationDate.
	 * @param registrationDate
	 */
	public void setRegistrationDate(int registrationDate) {
		this.registrationDate = registrationDate;
	}

	/** Modifier for attribute registrationTime.
	 * @param registrationTime
	 */
	public void setRegistrationTime(int registrationTime) {
		this.registrationTime = registrationTime;
	}

	/** Modifier for attribute birthDate from the class BirthDate.
	 * @param birthDate
	 */
	public void setBirthDate(BirthDate birthDate) {
		this.birthDate = birthDate;
	}

	/**
	 * @return string of data related to EMRecord object.
	 */
	public String toString () {
		return "<" + this.getClass().getName() + ">" + "[reportingFacilityProvince=" + reportingFacilityProvince +
				", institutionNumber=" + institutionNumber + ", functionalCentreAccount=" + functionalCentreAccount +
				", encounterSequence=" + encounterSequence + ", healthCareNumber=" + healthCareNumber + ", chartNumber=" +
				chartNumber + ", issuingProvince=" + issuingProvince + ", residenceCode=" + residenceCode +
				", gender=" + gender + ", submissionYear=" + submissionYear + ", adminViaAmbulance=" + adminViaAmbulance +
				", registrationDate=" + registrationDate + ", registrationTime=" + registrationTime + ", birthDate=" +
				birthDate + "]";


	}
}