package myHealthCareSystem;

/**
 * This class represents the birth date for a patient.  A birth date, once created
 * cannot be changed.
 * Lab Professor: Natalie Gluzman
 * Due Date: Mar 07, 2024
 * @description: Assignment 01
 * @author	Zarko Milojevic, ID 041113810
 * @version 21.0.1 2023-10-17 LTS
 * @see 	Java(TM) SE Runtime Environment (build 21.0.1+12-LTS-29)
 */

public class BirthDate {

	/*	Attributes			************************************/

	/** Birth day. */
	private	final int DAY;

	/** Birth month. */
	private	final int MONTH;

	/** Birth year. */
	private	final int YEAR;	

	/*	Constructors		************************************/

	/**
	 * Creates the object birth date for this patient.
	 * @param year		Year of birth (4 numeric characters)
	 * @param month	Month of birth (01 thru 12) (2 digit month)
	 * @param day	Day of birth. (2 digit day, 01 thru 30... depending upon the month and year)
	 */

	public	BirthDate(int YEAR, int MONTH, int DAY)	{
		this.DAY = DAY;
		this.MONTH = MONTH;
		this.YEAR = YEAR;
	}


	/*	Accessors			************************************/

	
	/** Accessor for attribute day.
	 * @return day
	 */

	public int	getDay()	{	
		return DAY;			
	}

	/** Accessor for attribute month.
	 * @return month
	 */

	public int	getMonth()	{	
		return MONTH;		
	}

	/** Accessor for attribute year.
	 * @return year
	 */
	public int	getYear()	{	
		return YEAR;		
	}

	/* Modifiers			************************************/


	/*	Normal Behavior	************************************/

	/**
	 * Method that will return the birth date as a string in specified form.
	 * @return	birth date as a string.
	 */
	public String formattedBirthDate()	{

		String formattedBirthDate = (YEAR+"/"+MONTH+"/"+DAY);
		return formattedBirthDate;
	}


	/**
	 * Method toString will show the required output as a meaningful string.
	 * @return	This object as a string.
	 */
	public String toString()	{
		return  "<" + this.getClass().getName() + ">" + "[year=" + YEAR + ", month=" + MONTH + ", day=" + DAY + "]"; 
	}

	/*	Helper Methods		************************************/

}
