/* Student Name: Zarko Milojevic
 * Lab Professor: Mel Sanschagrin
 * Due Date: Nov 27, 2023
 * Description: Assignment 02
 */

//This is a utility class that classifies the entered weight(s) of egg(s). 
public class CanadaAEggClassifier {
	
	/*
	 * This is a utility class with only static members, prevents
	 * instantiation.
	 */
	public CanadaAEggClassifier() { }
	
	//This method classifies the entered egg weight according to predefined criteria.
	public static char classifyCanadaAEgg(CanadaAEgg egg) {
		// This method will return a character based on the size designation for the egg:
		double weight=0; // Define the initial value for weight.
        char sizeDesignation=' '; // Declare and initialize the variable for size.

        weight=egg.getWeight(); // Call an instance for the Egg object.
        
        // J for Jumbo Size
        if(weight>=70) {
        	sizeDesignation='J';
      }
		// E for Extra Large Size
        if(weight>=63 && weight<70) {
        	sizeDesignation='E';
      }
		// L for Large Size
        if(weight>=56 && weight<63) {
        	sizeDesignation='L';
      }
		// M for Medium Size
        if(weight>=49 && weight<56) {
        	sizeDesignation='M';
      }
		// S for Small Size
        if(weight>=42 && weight<49) {
        	sizeDesignation='S';
      }
		// P for Peewee Size
        if(weight<42) {
        	sizeDesignation='P';
      }
		
		// Please refer to [1] to know how to determine the size designations for eggs.
		return sizeDesignation; //placeholder so the code will compile, update with the actual classification value
	}
	
}
/*
 * References:
 * [1] Egg Grade Requirements.  inspection.canada.ca.
 * https://inspection.canada.ca/about-cfia/acts-and-regulations/list-of-acts-and-regulations/documents-incorporated-by-reference/canadian-grade-compendium-volume-5/eng/1520869505643/1520869506282?chap=1 (Accessed Sept. 10, 2023).
 */


