/* Student Name: Zarko Milojevic
 * Lab Professor: Mel Sanschagrin
 * Due Date: Nov 27, 2023
 * Description: Assignment 02
 */

import java.util.Scanner; // Import scanner package.

// This class contains a main method that runs the program.
public class Assignment02 {

	/*This method runs the program. In brief:
	 * Ask the user for weight of eggs in grams.
	 * Classify given weight per egg size, report findings.
	 * Count and report on number of egg weights entered, and how many fall under each of size designations.
	 * User can even insert text, the program will not crash, no negative measurements are allowed.
	 * Ask user to continue, any form of yes will continue program.
	 */
	public static void main(String[] args) {
		CanadaAEgg egg = new CanadaAEgg(); // Call an instance of egg object.
        int count[]= {0,0,0,0,0,0}; // Declare and initialize variable-array.
        boolean condition=true; // Declare and initialize variable.
        String choice="yes"; // Declare and initialize variable.
        int totaleggs=0; // Declare and initialize variable.
        int i; // Declare and initialize variable.
        Scanner userInput=new Scanner (System.in);
		
        // Prompt the user to enter the weight of the egg 
        while(condition) {
        		
		// Set the weight into an instance of CanadaAEgg
		egg.setWeight(User.inputPositiveDouble("Enter the measured weight (in grams): "));
		
		// Use the toString method of class CanadaAEgg
		// to output the information for the egg
		System.out.println(egg.toString());
		
		// Use the CanadaAEggClassifier method to obtain a classification of an egg instance
		// by passing the CanadaAEgg reference-value as an argument.
		CanadaAEggClassifier eggClassifier= new CanadaAEggClassifier();
        char m=eggClassifier.classifyCanadaAEgg(egg);
		
        // Output a message to tell the user the classification of the egg instance
		// for example
		//   Egg is of Jumbo Size.
      if(m=='J') {
            System.out.println("Egg is Jumbo Size");
            count[0]++;
      }
      if(m=='E') {
            System.out.println("Egg is Extra Large Size");
            count[1]++;
      }
      if(m=='L') {
            System.out.println("Egg is Large Size");
            count[2]++;
      }
      if(m=='M') {
            System.out.println("Egg is Medium Size");
            count[3]++;
      }
      if(m=='S') {
            System.out.println("Egg is Small Size");
            count[4]++;
      }
      if(m=='P') {
            System.out.println("Egg is Peewee Size");
            count[5]++;
      }
      System.out.println(" ");
       
      for(i=0;i<1;i++) {
          totaleggs=totaleggs + 1;
    }
      
      // Collect a count of, and display to the user:
		// the number of egg weights entered
		// the number of egg weight measurements that fall under each of the size designations
		// for example
		//   Eggs entered: 10
		//   Jumbo Size: 2
		//   Extra Large Size: 1
		//   Large Size: 3
		//   Medium Size: 1
		//   Small Size: 1
		//   Peewee Size: 2
      System.out.println("Total Eggs entered: " +totaleggs);
      System.out.println("Jumbo Size: " +count[0] );
      System.out.println("Extra Large Size: " +count[1] );
      System.out.println("Large Size: " +count[2] );
      System.out.println("Medium Size: " +count[3] );
      System.out.println("Small Size: " +count[4] );
      System.out.println("Peewee Size: " +count[5] );
      
      // Print out your name, student ID number, and lab section number on the screen
		// for example
		//   Program by Teddy Yap, 0123456789, Lab Section 999
      System.out.println("Program by Zarko Milojevic, 041113810, Lab Section 362");
		
		// Using a loop ask if there is more data to enter (yes, no) and continue
		// only if the user enters some form of yes
		// e.g. "YES" "yEs" "yeS" would be acceptable (any capitalization)
		// if yes, processing should repeat starting with the output of the user-instructions
		// You can use any decision structure or loop for this program,
		// however a for-loop is not recommended for the main method logic
      System.out.println(" ");
      System.out.print("Continue(yes/no):");
      choice=userInput.next();
     
      if(choice.equalsIgnoreCase("yes"))
      {
            condition=true;
      }
      else
      {
            System.out.println("Program has shut down.");
            System.out.println(" ");
            condition=false;
      }
     }
	userInput.close();
	}
}
