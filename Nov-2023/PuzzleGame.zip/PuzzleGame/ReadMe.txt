This is edited and modified Puzzle Game, using Java. Date is Nov 30th, 2023.
The class was created using AWT/Swing with event handling, for smoother graphical interface.
