/* Student Name: Zarko Milojevic
 * Lab Professor: Mel Sanschagrin
 * Due Date: Oct 14, 2023
 * Modified: Oct 14, 2023.
 */ 
	/* Description: Assignment 01
	   This class contains private variables radius and height,
	   a default constructor, overloaded/parameterized constructor,
	   an accessor and a mutator method for each variable, 
	   a work method to calculate variable volCone.
	*/

// VolumeOfCone class with constructor and methods

class VolumeOfCone {
	
	// declaration of instance variables, no unit of measurement specified
	private double radius;
	private double height;
	
	// Creating a default constructor
	public VolumeOfCone () {
		this(0,0);
	}
	
	// Creating overloaded constructor
	
	public VolumeOfCone(double radius, double height) {
		this.radius=radius;
		this.height=height;
	}
	// Creating accessor for the variable radius
		public double getRadius() {
			return radius;
		}
		
	// Creating mutator for the variable radius
		public void setRadius(double radius) {
			this.radius=radius;
		}
	
	// Creating accessor for variable height
		public double getHeight() {
		return height;
		}
		
	// Creating mutator for variable height
		public void setHeight(double height) {
			this.height=height;
		}
		
	/* Creating worker method for volCone; formula taken from [1].
	 * V = (1/3)* Pi * r * r * h, in cubic units.
	 * Reference: [1] CueMath, "Volume of Cone"
	 * Available: https://www.cuemath.com/measurement/volume-of-cone/ 
	 * [Accessed Oct 13, 2023].
	 */
		public double calculateVolumeCone() {
			return (1.0/3.0)*Math.PI*Math.pow(radius,2)*height;
		}
}
