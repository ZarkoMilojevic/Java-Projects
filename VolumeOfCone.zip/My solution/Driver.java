/* Student Name: Zarko Milojevic
 * Lab Professor: Mel Sanschagrin
 * Due Date: Oct 14th, 2023
 * Modified: Oct 14th, 2023.
 * Description: Assignment 1 file
*/

import java.util.Scanner;

		// Driver class with main method which will run program.
public class Driver {
		
	public static void main(String[] args) {
		Scanner inputUser=new Scanner(System.in); // Create Scanner object
		double radius, height, volCone; // Declare variables.
		VolumeOfCone cone=new VolumeOfCone(); // Create an object with def.const.
		
		// Prompt user to enter values for radius.
		System.out.print("Enter value for radius in cm: ");
		radius=inputUser.nextDouble();
		cone.setRadius(radius); // Assign input value to private data member.
				
		// Prompt user to enter values for height.
		System.out.print("Enter value for height in cm: ");
		height=inputUser.nextDouble();
		cone.setHeight(height); // Assign input value to private data member.
		
		// Compute and display the volume of cone formatted to two decimal places.
		volCone=cone.calculateVolumeCone();
		System.out.printf("The volume of cone is (in cm^3): %.2f%n", volCone);
		
		// Display my full name.
		System.out.print("Program created by Zarko Milojevic.");
		inputUser.close();
	}

}
